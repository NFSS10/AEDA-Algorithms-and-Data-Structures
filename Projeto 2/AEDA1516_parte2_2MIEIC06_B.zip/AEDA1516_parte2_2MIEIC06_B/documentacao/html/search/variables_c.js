var searchData=
[
  ['tipo',['Tipo',['../class_transporte.html#af2c1294e029907643028edc27e9308bf',1,'Transporte']]],
  ['tipologia',['Tipologia',['../class_apartamento.html#aa8c13c34ebd26ae5f38f582d34d83d04',1,'Apartamento']]],
  ['transportespublicos',['TransportesPublicos',['../class_condominio.html#aaf81c703626cbe83a25b5d1b0bf9f4cf',1,'Condominio']]]
];
