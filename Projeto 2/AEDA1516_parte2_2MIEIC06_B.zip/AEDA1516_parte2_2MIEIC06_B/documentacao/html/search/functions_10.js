var searchData=
[
  ['toogle_5fativ_5fpontoparagem',['toogle_Ativ_PontoParagem',['../class_condominio.html#ad33933f92e3d13ad7090e28e0e38af85',1,'Condominio']]],
  ['tra_5fop1',['Tra_op1',['../class_menu.html#a477b0bf0c20f7e3387eb8e21133b467c',1,'Menu']]],
  ['tra_5fop2',['Tra_op2',['../class_menu.html#abef9fc5af4771c3b843d903cd1e6c890',1,'Menu']]],
  ['tra_5fop3',['Tra_op3',['../class_menu.html#ad698161c848966f75dea6b320d04b524',1,'Menu']]],
  ['tra_5fop4',['Tra_op4',['../class_menu.html#a5c915b250d5c921747c1e8d3ba52e288',1,'Menu']]],
  ['transporte',['Transporte',['../class_transporte.html#a0cbb4b20eea36e3011b8b3208a812778',1,'Transporte::Transporte()'],['../class_transporte.html#aab5d6ec083e0912ed259c0110599bbc1',1,'Transporte::Transporte(string tipo, string destino, string ponto_paragem, unsigned int dist_ponto_paragem)'],['../class_transporte.html#afa208443833e0ad48737a3f75c864f87',1,'Transporte::Transporte(string tipo, string destino, string ponto_paragem, unsigned int dist_ponto_paragem, bool estado)']]],
  ['transportes_5finiciar',['Transportes_iniciar',['../class_menu.html#ac9d4b948d5664bd46068540981de19d4',1,'Menu']]]
];
