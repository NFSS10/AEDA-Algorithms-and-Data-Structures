var searchData=
[
  ['red',['RED',['../_menu_8cpp.html#a8d23feea868a983c8c2b661e1e16972f',1,'Menu.cpp']]]
];
