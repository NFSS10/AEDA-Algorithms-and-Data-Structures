var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstvwy~",
  1: "abcdehmstv",
  2: "abcdehmstv",
  3: "abcdefghilmnoprstv~",
  4: "acdehilmnprstv",
  5: "h",
  6: "b",
  7: "bcdeglmrwy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "related",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Friends",
  7: "Macros"
};

