var searchData=
[
  ['magenta',['MAGENTA',['../_menu_8cpp.html#a6f699060902f800f12aaae150f3a708e',1,'Menu.cpp']]]
];
