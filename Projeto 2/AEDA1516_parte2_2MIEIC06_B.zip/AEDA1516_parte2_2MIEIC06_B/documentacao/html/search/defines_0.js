var searchData=
[
  ['black',['BLACK',['../_menu_8cpp.html#a7b3b25cba33b07c303f3060fe41887f6',1,'Menu.cpp']]],
  ['blue',['BLUE',['../_menu_8cpp.html#a79d10e672abb49ad63eeaa8aaef57c38',1,'Menu.cpp']]],
  ['brown',['BROWN',['../_menu_8cpp.html#ab2baea56ece91306020afd6d77fd19f9',1,'Menu.cpp']]]
];
