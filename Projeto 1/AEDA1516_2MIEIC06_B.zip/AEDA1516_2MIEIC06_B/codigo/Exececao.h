#pragma once

#include<iostream>


using namespace std;

class ValorInvalido 
{
public:
	/**
	* Construtor da excecao "Valor Invalido"
	*/
	ValorInvalido() { cout << "Valor Invalido" << endl; }
};

