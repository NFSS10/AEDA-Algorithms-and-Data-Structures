var searchData=
[
  ['area_5fexterior',['Area_Exterior',['../class_vivenda.html#a25ee678aab6998afdd0a33ec3fc0870a',1,'Vivenda']]],
  ['area_5fhabitacional',['Area_Habitacional',['../class_habitacao.html#a1ceb54df7d71ddd19126c6b64f51c0da',1,'Habitacao']]]
];
