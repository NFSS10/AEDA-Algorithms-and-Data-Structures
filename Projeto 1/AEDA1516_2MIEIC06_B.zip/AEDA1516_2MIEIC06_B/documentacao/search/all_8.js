var searchData=
[
  ['nif',['NIF',['../class_condomino.html#a3ce9b6f2e83660c88d6e4c312c3c9e4b',1,'Condomino']]],
  ['nome',['Nome',['../class_condominio.html#abb875072cddd5dba7f918c3007c0f870',1,'Condominio::Nome()'],['../class_condomino.html#a13f8bbe15bcd5599d5c5aa796ef06f47',1,'Condomino::Nome()'],['../class_servico.html#a4c9584c12b136bf3e7ac1d25ed080bb0',1,'Servico::Nome()']]],
  ['numprestserv',['numPrestServ',['../class_servico.html#aedbde128f03734b17eeac6bd5eb0fabe',1,'Servico']]]
];
